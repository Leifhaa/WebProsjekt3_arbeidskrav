import React from 'react';

export const Home = () => {
    return (
        <div>
            <h3>Welcome to project editor V3! The new revolution of project administration</h3>
        </div>
    )
}